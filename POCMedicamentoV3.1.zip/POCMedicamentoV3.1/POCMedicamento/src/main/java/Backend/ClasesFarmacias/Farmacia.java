/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.ClasesFarmacias;

/**
 *
 * @author sotoj
 */
public class Farmacia {
    private int nit;
    private String razonSocial;
    private String represetanteLegal;
    private String direccion;
    private String estado;

    public Farmacia(int nit, String razonSocial, String represetanteLegal, String direccion, String estado ) {
        this.nit = nit;
        this.razonSocial = razonSocial;
        this.represetanteLegal = represetanteLegal;
        this.direccion = direccion;
        this.estado = estado;
    }

    public int getNit() {
        return nit;
    }

    public void setNit(int nit) {
        this.nit = nit;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getRepresetanteLegal() {
        return represetanteLegal;
    }

    public void setRepresetanteLegal(String represetanteLegal) {
        this.represetanteLegal = represetanteLegal;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }


    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    
    
    
}
