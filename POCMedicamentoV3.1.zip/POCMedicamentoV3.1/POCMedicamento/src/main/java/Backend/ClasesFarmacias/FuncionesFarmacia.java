/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.ClasesFarmacias;

import Backend.ClasesFarmacias.Farmacia;
import com.mycompany.pocmedicamento.data.DatabaseConnect;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sotoj
 * 
 * ESTRUCTURA LECTURA DE FARMACIA
 *  private int nit; (4)
    private String razonSocial; (17)
    private String represetanteLegal; (17)
    private boolean estado; 1
 */
public class FuncionesFarmacia {
    
    public static final String NOM_ARCHIVO = "data//farmacia.txt";
    

    public static final int TAM_RAZON = 15;
    public static final int TAM_REPRESENTANTE = 15;
    public static final int TAM_REGISTRO_FAR = 39;
    
    private static Connection conn = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;
    
    public static boolean cargarEnArchivo(Farmacia far){
        try {
            conn = DatabaseConnect.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                //String insertDataSQL = "INSERT INTO FARMACIA (NIT, RAZON_SOCIAL, REPRESENTANTE_LEGAL, DIRECCION, ESTADO) VALUES (" + dpto.getCodigo() + ",'" + dpto.getNombre() + "')";
                String insertDataSQL = "INSERT INTO FARMACIA (NIT, RAZON_SOCIAL, REPRESENTANTE_LEGAL, DIRECCION, ESTADO) " +
                       "VALUES (" + far.getNit() + ", " +
                       "'" + far.getRazonSocial() + "', " +
                       "'" + far.getRepresetanteLegal() + "', " +
                       "'" + far.getDireccion() + "', " +
                       "'" + far.getEstado() + "')";
                int rowsAffected = stmt.executeUpdate(insertDataSQL);
                conn.close();
            } else {
                return false;
            }
            
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
            return false;
        }
        return true;
    }

    public static List listarFarmacias()
    {
        //Se declara una variable llamada medicamentos de tipo ArrayList que permite "almacenar" objetos de tipo Medicamento
        List <Farmacia> farmacias = new ArrayList();
        int nit;
        String razonSocial;
        String represetanteLegal;
        String direccion;
        String estado;
        
        
        //Variable de tipo empleado - NO hay objeto aún
        Farmacia far;
        
        try 
        {
            conn = DatabaseConnect.getConnection();
            if (conn != null) 
            {
                stmt = conn.createStatement();
                String selectDataSQL = "SELECT NIT, RAZON_SOCIAL, REPRESENTANTE_LEGAL, DIRECCION, ESTADO FROM FARMACIA";
                rs = stmt.executeQuery(selectDataSQL);
                
                while(rs.next())
                {
                    //Se leen los datos del archivo en el mismo orden en que fueron escritos
                    nit = rs.getInt("NIT");
                    razonSocial = rs.getString("RAZON_SOCIAL");
                    represetanteLegal = rs.getString("REPRESENTANTE_LEGAL");
                    direccion = rs.getString("DIRECCION"); 
                    estado = rs.getString("ESTADO");
                            
                    far = new Farmacia(nit, razonSocial, represetanteLegal, direccion, estado);
                    //Se adiciona al ArrayList empleados el empleado leido
                   
                    farmacias.add(far);
                    
                }
                    
            }

        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return farmacias;
    }

    public static Farmacia buscarFarmacia(int nit)
    {
            Farmacia far = null;
            conn = DatabaseConnect.getConnection();
            if (conn != null) 
            {

                try 
                {
                    stmt = conn.createStatement();
                    String selectDataSQL = "SELECT NIT, RAZON_SOCIAL, REPRESENTANTE_LEGAL, DIRECCION, ESTADO FROM FARMACIA";
                    rs = stmt.executeQuery(selectDataSQL);
                    
                    int nitLeido;
                    String razonSocial;
                    String represetanteLegal;
                    String direccion;
                    String estado;

                    while(rs.next())
                    {
                        //Se leen los datos del archivo en el mismo orden en que fueron escritos
                        nitLeido = rs.getInt("NIT");
                        razonSocial = rs.getString("RAZON_SOCIAL");
                        represetanteLegal = rs.getString("REPRESENTANTE_LEGAL");
                        direccion = rs.getString("DIRECCION"); 
                        estado = rs.getString("ESTADO");
                        
                        if(nitLeido == nit )
                        {
                            far = new Farmacia(nit, razonSocial, represetanteLegal, direccion, estado);
                            break;
                        }
                        else
                        {
                            far = null;
                        }
                    }
                    
                } catch (Exception ex) {
                    System.out.println("Error! " + ex);
                }
            }

            return far;
    }

    public static boolean eliminarFarmacia(Farmacia far) {
        try {
            conn = DatabaseConnect.getConnection();
            if (conn != null) 
            {
                stmt = conn.createStatement();

                String updateDataSQL = "UPDATE FARMACIA SET " +
                                   "RAZON_SOCIAL = '" + far.getRazonSocial() + "', " +
                                   "REPRESENTANTE_LEGAL = '" + far.getRepresetanteLegal() + "', " +
                                   "DIRECCION = '" + far.getDireccion() + "', " +
                                   "ESTADO = 'IN' " +
                                   "WHERE NIT = " + far.getNit();
                int rowsAffected = stmt.executeUpdate(updateDataSQL);
                conn.close();
            } else 
            {
                return false;
            }
            
        } catch(Exception e){
            System.out.println("Error: " + e);
            return false;
        }
        return true;
    }

    public static boolean actualizarFarmacia(Farmacia far)
    {

        try {
            conn = DatabaseConnect.getConnection();
            if (conn != null) 
            {
                stmt = conn.createStatement();

                String updateDataSQL = "UPDATE FARMACIA SET " +
                                   "RAZON_SOCIAL = '" + far.getRazonSocial() + "', " +
                                   "REPRESENTANTE_LEGAL = '" + far.getRepresetanteLegal() + "', " +
                                   "DIRECCION = '" + far.getDireccion() + "', " +
                                   "ESTADO = '" + far.getEstado() + "' " +
                                   "WHERE NIT = " + far.getNit();
                int rowsAffected = stmt.executeUpdate(updateDataSQL);
                conn.close();
            } else 
            {
                return false;
            }
            
        } catch(Exception e){
            System.out.println("Error: " + e);
            return false;
        }
        return true;
    }
    
    public static int contarFarmacias()
    {
        int contador = 0;

        try {

            RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "rw");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                // lee registro completo
                file.readInt();      //
                file.readUTF();      // 
                file.readUTF();      // 
                file.readBoolean();  // 

                contador++;
            }

            file.close();

        } catch(Exception e){
            System.out.println("Error: " + e);
        }

        return contador;
    }
    
    
    
    public static String mostrarFarmacias()
    {
        StringBuilder info = new StringBuilder();

        try {

            RandomAccessFile file = new RandomAccessFile(NOM_ARCHIVO, "r");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                int nit = file.readInt();
                String razonSocial = file.readUTF();
                String represetanteLegal = file.readUTF();
                boolean estado = file.readBoolean();

                info.append("===== Farmacia =====\n");
                info.append("Nit: ").append(nit).append("\n");
                info.append("Razon Social: ").append(razonSocial).append("\n");
                info.append("Representante Legal: ").append(represetanteLegal).append("\n");
                info.append("Estado: ").append(estado ? "ACTIVO" : "NO ACTIVO").append("\n\n");
            }

            file.close();

        } catch(Exception e){
            return "Error al leer archivo";
        }

        return info.toString();
    }
    
    public static int contarMedicamentosFarmacia(int nit)
    {
        int contador = 0;

        try {
            
            int nit2;

            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "rw");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                // lee registro completo
                file.readUTF();      // nombre
                file.readUTF();      // id
                file.readDouble();   // gramaje
                file.readUTF();      // tipo
                file.readDouble();   // precio
                file.readBoolean();  // stock
                nit2 = file.readInt();      // nit Farmacia 
                

                if (nit == nit2)
                {
                    contador++;
                }

            }

            file.close();

        } catch(Exception e){
            System.out.println("Error: " + e);
        }

        return contador;
    }
}
