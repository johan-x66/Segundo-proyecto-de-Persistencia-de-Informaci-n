/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.ClasesMedicamento;

import Backend.ClasesMedicamento.Medicamento;
import Backend.ClasesFarmacias.Farmacia;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Backend.ClasesFarmacias.FuncionesFarmacia;
import com.mycompany.pocmedicamento.data.DatabaseConnect;
import Frontend.GUIPrincipal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author AyLZz
 * 
 * Se maneja el siguiente orden para R & W en el registro:

 * private String nombre; (22)
    private String id; (14)
    private double gramaje; (8)
    private String tipoMedicamento; (17)
    private double precio; (8)
    private boolean Stock; (1)
    private int nitFarmacia; (4)
 */
public class FuncionesMedicamento 
{
   
    public static String adjustStringLength(String input, int n) {
        if (input == null) {
            return " ".repeat(n);
        }

        if (input.length() > n) {
            return input.substring(0, n);
        } else {
            return String.format("%-" + n + "s", input);
        }
    }
    
    private static Connection conn = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;
    

    
    public static boolean cargarEnArchivo(Medicamento med) {
        String sqlVerificar = "SELECT COUNT(*) FROM FARMACIA WHERE NIT = " + med.getNitFarmacia();
        String sqlInsert = "INSERT INTO MEDICAMENTO (ID, NOMBRE, GRAMAJE, PRECIO_UNITARIO, ESTADO, NITFARMACIA) " +
                           "VALUES (" + med.getId() + ", '" + med.getNombre() + "', " + 
                           med.getGramaje() + ", " + med.getPrecio() + ", '" + 
                           med.getEstado()+ "', " + med.getNitFarmacia() + ")";

        try {
            conn = DatabaseConnect.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery(sqlVerificar);

                if (rs.next() && rs.getInt(1) > 0) {
                    int rowsAffected = stmt.executeUpdate(sqlInsert);
                    conn.close();
                    return rowsAffected > 0;
                } else {
                    System.out.println("Error: La farmacia con NIT " + med.getNitFarmacia() + " no existe.");
                    conn.close();
                    return false;
                }
            }
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
            return false;
        }
        return false;
    }   

    public static List<Medicamento> listarMedicamentos() {
    List<Medicamento> medicamentos = new ArrayList<>();

        try {
            conn = DatabaseConnect.getConnection();
            if (conn != null) {
                stmt = conn.createStatement();
                rs = stmt.executeQuery("SELECT * FROM MEDICAMENTO");

                while(rs.next()) {
                    Medicamento med = new Medicamento(
                        rs.getInt("ID"),
                        rs.getString("NOMBRE"),
                        rs.getDouble("GRAMAJE"),
                        rs.getDouble("PRECIO_UNITARIO"),
                        rs.getString("ESTADO"),
                        rs.getInt("NITFARMACIA")
                    );
                    medicamentos.add(med);
                }
                conn.close();
            }
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }
        return medicamentos;
    }

    public static Medicamento buscarMedicamento(int idBuscada)
    {
        Medicamento med = null;
        try 
        {
            
            conn = DatabaseConnect.getConnection();
            if (conn != null) 
            {
                int id;
                String nombre;
                double gramaje;
                double precio;
                String estado;
                int nitFarmacia;
                
                stmt = conn.createStatement();
                String selectDataSQL = "SELECT * FROM MEDICAMENTO"; 
                rs = stmt.executeQuery(selectDataSQL);

                
                while(rs.next()){
                    //Se leen los datos del archivo en el mismo orden en que fueron escritos
                    id = rs.getInt("ID");
                    nombre = rs.getString("NOMBRE");
                    gramaje = rs.getDouble("GRAMAJE");
                    precio = rs.getDouble("PRECIO_UNITARIO");
                    estado = rs.getString("ESTADO");
                    nitFarmacia = rs.getInt("NITFARMACIA");

                    if(idBuscada == id )
                        {
                            
                            med = new Medicamento(id, nombre, gramaje, precio, estado, nitFarmacia);
                            break;
                        }
                        else
                        {
                            med = null;
                        }
            }
        }
            
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return med;
    }

    
    public static boolean eliminarMedicamento(Medicamento med) {
        
        try {
            conn = DatabaseConnect.getConnection();
            if (conn != null) 
            {
                stmt = conn.createStatement();

                String updateDataSQL = "UPDATE MEDICAMENTO SET " +
                                   "NOMBRE = '" + med.getNombre() + "', " +
                                   "GRAMAJE = " + med.getGramaje() + ", " +
                                   "PRECIO_UNITARIO = " + med.getPrecio() + ", " +
                                   "ESTADO = 'IN', " +
                                   "NITFARMACIA = " + med.getNitFarmacia() + " " +
                                   "WHERE ID = " + med.getId();
                
                int rowsAffected = stmt.executeUpdate(updateDataSQL);
                conn.close();
            } else 
            {
                return false;
            }
            
        } catch(Exception e){
            System.out.println("Error: " + e);
            return false;
        }
        return true;
    }

    public static boolean actualizarMedicamento(Medicamento med)
    {
        try {
            conn = DatabaseConnect.getConnection();
            if (conn != null) 
            {
                stmt = conn.createStatement();

                String updateDataSQL = "UPDATE MEDICAMENTO SET " +
                                   "NOMBRE = '" + med.getNombre() + "', " +
                                   "GRAMAJE = " + med.getGramaje() + ", " +
                                   "PRECIO_UNITARIO = " + med.getPrecio() + ", " +
                                   "ESTADO = '" + med.getEstado() + "', " +
                                   "NITFARMACIA = " + med.getNitFarmacia() + " " +
                                   "WHERE ID = " + med.getId();
                
                int rowsAffected = stmt.executeUpdate(updateDataSQL);
                conn.close();
            } else 
            {
                return false;
            }
            
        } catch(Exception e){
            System.out.println("Error: " + e);
            return false;
        }
        return true;
    }
    
    public static double sumarMedicamentos() {
        double suma = 0;
        String sql = "SELECT SUM(PRECIO_UNITARIO) FROM MEDICAMENTO";

        try (Connection conn = DatabaseConnect.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                // El resultado de la suma viene en la primera columna
                suma = rs.getDouble(1);
            }

        } catch (Exception e) {
            System.out.println("Error al sumar medicamentos: " + e);
        }

        return suma;
}
    
    
    
    public static String mostrarMedicamentos()
    {
        StringBuilder info = new StringBuilder();

        try {

            RandomAccessFile file = new RandomAccessFile("data//registros.txt", "r");

            file.seek(0);

            while(file.getFilePointer() < file.length())
            {
                String nombre = file.readUTF();
                String id = file.readUTF();
                double gramaje = file.readDouble();
                String tipo = file.readUTF();
                double precio = file.readDouble();
                boolean stock = file.readBoolean();
                int nitFarmacia = file.readInt();

                info.append("===== MEDICAMENTO =====\n");
                info.append("Nombre: ").append(nombre).append("\n");
                info.append("ID: ").append(id).append("\n");
                info.append("Gramaje: ").append(gramaje).append("\n");
                info.append("Tipo: ").append(tipo).append("\n");
                info.append("Precio: ").append(precio).append("\n");
                info.append("Stock: ").append(stock ? "Disponible" : "Agotado").append("\n");
                info.append("Nit Farmacia: ").append(nitFarmacia).append("\n");
            }

            file.close();

        } catch(Exception e){
            return "Error al leer archivo";
        }

        return info.toString();
    }
    
     public static boolean cambiarNit(int idBuscado) {
        try {
                conn = DatabaseConnect.getConnection();
                if (conn != null) {
                    stmt = conn.createStatement();

                    // Estructura concatenada (estilo que usas en cargarEnArchivo)
                    String deleteDataSQL = "DELETE FROM MEDICAMENTO WHERE ID = " + idBuscado;
                    int rowsAffected = stmt.executeUpdate(deleteDataSQL);
                    conn.close();

                    return rowsAffected > 0;
                }
        } catch (Exception ex) {
        System.out.println("Error al eliminar: " + ex);
                return false;
        }
        return false;
        
    }
    
}