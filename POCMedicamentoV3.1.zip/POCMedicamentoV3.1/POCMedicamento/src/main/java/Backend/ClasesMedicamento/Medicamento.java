/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.ClasesMedicamento;

/**
 *
 * @author AyLZz
 */
public class Medicamento 
{
    
    //Atributos escenciales. (La idea es añadir unos cuantos mas en un futuro)
    
    private int id;
    private String nombre;
    private double gramaje;
    private double precio;
    private String estado;
    private int nitFarmacia;

    public Medicamento(int id, String nombre, double gramaje, double precio, String estado, int nitFarmacia) {
        this.id = id;
        this.nombre = nombre;
        this.gramaje = gramaje;
        this.precio = precio;
        this.estado = estado;
        this.nitFarmacia = nitFarmacia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getGramaje() {
        return gramaje;
    }

    public void setGramaje(double gramaje) {
        this.gramaje = gramaje;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getNitFarmacia() {
        return nitFarmacia;
    }

    public void setNitFarmacia(int nitFarmacia) {
        this.nitFarmacia = nitFarmacia;
    }
    
}